module.exports=[99131,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_exam-booking_page_actions_1exdw8u.js.map