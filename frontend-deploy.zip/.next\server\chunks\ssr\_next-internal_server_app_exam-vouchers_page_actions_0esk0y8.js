module.exports=[84024,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_exam-vouchers_page_actions_0esk0y8.js.map