var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/revalidate/blog/route.js")
R.c("server/chunks/[root-of-the-server]__1jwktfc._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_next_1tydojh._.js")
R.c("server/chunks/_next-internal_server_app_api_revalidate_blog_route_actions_16v2euw.js")
R.m(93775)
module.exports=R.m(93775).exports
