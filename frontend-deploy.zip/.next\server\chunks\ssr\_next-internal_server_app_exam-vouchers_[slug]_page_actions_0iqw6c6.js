module.exports=[38442,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_exam-vouchers_%5Bslug%5D_page_actions_0iqw6c6.js.map