module.exports=[38766,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_calculators_page_actions_1q4wex7.js.map