globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/3Bl6O_MGAzOcdVkoqEcoU/_buildManifest.js",
    "static/3Bl6O_MGAzOcdVkoqEcoU/_ssgManifest.js",
    "static/3Bl6O_MGAzOcdVkoqEcoU/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/1mkbuudhndal5.js",
    "static/chunks/1t2a6qluwgklf.js",
    "static/chunks/turbopack-2dygyxj7b9jzs.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
