module.exports=[33313,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}])},78221,function(a){a.n(a.i(33313))}];

//# sourceMappingURL=app_blog_layout_tsx_1r1mm7c._.js.map