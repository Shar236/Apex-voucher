module.exports=[62296,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_revalidate_blog_route_actions_16v2euw.js.map