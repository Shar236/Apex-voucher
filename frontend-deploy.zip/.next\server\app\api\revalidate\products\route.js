var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/revalidate/products/route.js")
R.c("server/chunks/[root-of-the-server]__1s5x-j0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_next_1tydojh._.js")
R.c("server/chunks/_next-internal_server_app_api_revalidate_products_route_actions_0zfnwcf.js")
R.m(58991)
module.exports=R.m(58991).exports
