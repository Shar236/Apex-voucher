module.exports=[92459,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_how-to-reschedule-cancel-pte-exam_page_actions_1mu-n88.js.map