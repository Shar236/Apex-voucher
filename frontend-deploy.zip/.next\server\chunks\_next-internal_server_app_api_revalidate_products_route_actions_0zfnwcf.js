module.exports=[95822,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_revalidate_products_route_actions_0zfnwcf.js.map