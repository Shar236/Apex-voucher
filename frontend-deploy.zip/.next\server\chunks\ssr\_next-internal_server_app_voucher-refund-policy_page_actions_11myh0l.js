module.exports=[95883,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_voucher-refund-policy_page_actions_11myh0l.js.map