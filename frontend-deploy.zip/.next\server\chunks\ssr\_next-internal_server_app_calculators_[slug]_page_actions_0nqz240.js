module.exports=[37066,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_calculators_%5Bslug%5D_page_actions_0nqz240.js.map